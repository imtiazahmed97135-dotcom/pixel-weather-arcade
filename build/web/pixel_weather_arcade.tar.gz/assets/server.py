import asyncio
import json
import logging
import os
import websockets
from websockets.exceptions import ConnectionClosed

# Set up logging for server monitoring
logging.basicConfig(
    level=logging.INFO,
    format="%(asctime)s [%(levelname)s] %(message)s"
)

# Global dictionary to track connected players: { websocket: player_data_dict }
CONNECTED_PLAYERS = {}

async def register(websocket):
    """Register a new connected client."""
    CONNECTED_PLAYERS[websocket] = {
        "id": id(websocket),
        "x": 400,
        "y": 300,
        "name": "Player",
        "score": 0
    }
    logging.info(f"New connection established: ID {id(websocket)}")

async def unregister(websocket):
    """Remove a disconnected client and notify other players."""
    if websocket in CONNECTED_PLAYERS:
        player_id = CONNECTED_PLAYERS[websocket]["id"]
        del CONNECTED_PLAYERS[websocket]
        logging.info(f"Player disconnected: ID {player_id}")
        
        # Broadcast player left event to remaining clients
        leave_msg = json.dumps({"type": "player_left", "id": player_id})
        await broadcast(leave_msg)

async def broadcast(message):
    """Broadcast a JSON message to all currently connected clients."""
    if CONNECTED_PLAYERS:
        # Create a snapshot of current connections to prevent mutation issues
        active_sockets = list(CONNECTED_PLAYERS.keys())
        websockets.broadcast(active_sockets, message)

async def handle_client(websocket):
    """Handle incoming messages and lifecycle for an individual client."""
    await register(websocket)
    try:
        async for message in websocket:
            try:
                data = json.loads(message)
                msg_type = data.get("type")

                # 1. Handle initial player join / setup
                if msg_type == "join":
                    CONNECTED_PLAYERS[websocket]["name"] = data.get("name", "Player")
                    response = {
                        "type": "welcome",
                        "id": CONNECTED_PLAYERS[websocket]["id"]
                    }
                    await websocket.send(json.dumps(response))

                # 2. Handle player movement / state updates
                elif msg_type == "update":
                    player = CONNECTED_PLAYERS[websocket]
                    player["x"] = data.get("x", player["x"])
                    player["y"] = data.get("y", player["y"])
                    player["score"] = data.get("score", player["score"])

                # 3. Handle custom game events (e.g., shooting, powerups)
                elif msg_type == "action":
                    action_msg = json.dumps({
                        "type": "player_action",
                        "id": CONNECTED_PLAYERS[websocket]["id"],
                        "action": data.get("action")
                    })
                    await broadcast(action_msg)

            except json.JSONDecodeError:
                logging.warning("Received invalid JSON payload")

    except ConnectionClosed:
        pass
    finally:
        await unregister(websocket)

async def game_state_loop():
    """Periodic loop running at 30 FPS to broadcast state to all clients."""
    while True:
        if CONNECTED_PLAYERS:
            # Construct active players list
            players_list = list(CONNECTED_PLAYERS.values())
            state_msg = json.dumps({
                "type": "state_update",
                "players": players_list
            })
            await broadcast(state_msg)
        
        # ~30 updates per second (30 FPS)
        await asyncio.sleep(1 / 30)

async def main():
    # Read PORT from environment variable (for Railway/Heroku) or default to 8765
    port = int(os.environ.get("PORT", 8765))
    host = "0.0.0.0"  # Listen on all network interfaces

    logging.info(f"Starting WebSocket server on {host}:{port}...")

    # Start the WebSocket server and the broadcast loop concurrently
    async with websockets.serve(handle_client, host, port):
        await game_state_loop()

if __name__ == "__main__":
    try:
        asyncio.run(main())
    except KeyboardInterrupt:
        logging.info("Server shut down manually.")