import asyncio
import json
import pygame
import sys
import websockets

# Configuration
SCREEN_WIDTH = 800
SCREEN_HEIGHT = 600
SERVER_URI = "ws://localhost:8765"  # Replace with production URL (e.g. wss://your-server.up.railway.app)

# Local player state
player_data = {
    "x": 400,
    "y": 300,
    "speed": 5,
    "id": None,
    "name": "Player1"
}

# Store state of all connected players received from server
other_players = {}

async def receive_server_data(websocket):
    """Background coroutine to continuously listen for state updates from server."""
    global other_players
    try:
        async for message in websocket:
            data = json.loads(message)
            msg_type = data.get("type")

            if msg_type == "welcome":
                player_data["id"] = data.get("id")

            elif msg_type == "state_update":
                # Save latest position data for all connected players
                players_list = data.get("players", [])
                other_players = {p["id"]: p for p in players_list if p["id"] != player_data["id"]}

    except websockets.ConnectionClosed:
        print("Disconnected from server.")
    except Exception as e:
        print(f"Network error: {e}")

async def main():
    pygame.init()
    screen = pygame.display.set_mode((SCREEN_WIDTH, SCREEN_HEIGHT))
    pygame.display.set_caption("Pixel Weather Arcade - Multiplayer")
    clock = pygame.time.Clock()

    # Attempt to establish WebSocket connection
    print(f"Connecting to server at {SERVER_URI}...")
    try:
        async with websockets.connect(SERVER_URI) as websocket:
            print("Connected to game server!")
            
            # Send initial join packet
            await websocket.send(json.dumps({"type": "join", "name": player_data["name"]}))

            # Start listening task in the background
            asyncio.create_task(receive_server_data(websocket))

            running = True
            while running:
                # 1. Event Handling
                for event in pygame.event.get():
                    if event.type == pygame.QUIT:
                        running = False

                # 2. Player Input Movement
                keys = pygame.key.get_pressed()
                moved = False
                if keys[pygame.K_LEFT] or keys[pygame.K_a]:
                    player_data["x"] -= player_data["speed"]
                    moved = True
                if keys[pygame.K_RIGHT] or keys[pygame.K_d]:
                    player_data["x"] += player_data["speed"]
                    moved = True
                if keys[pygame.K_UP] or keys[pygame.K_w]:
                    player_data["y"] -= player_data["speed"]
                    moved = True
                if keys[pygame.K_DOWN] or keys[pygame.K_s]:
                    player_data["y"] += player_data["speed"]
                    moved = True

                # Keep local player within bounds
                player_data["x"] = max(0, min(SCREEN_WIDTH - 32, player_data["x"]))
                player_data["y"] = max(0, min(SCREEN_HEIGHT - 32, player_data["y"]))

                # Send player state update to server
                if moved:
                    update_pkg = {
                        "type": "update",
                        "x": player_data["x"],
                        "y": player_data["y"]
                    }
                    await websocket.send(json.dumps(update_pkg))

                # 3. Drawing / Rendering
                screen.fill((30, 30, 40))  # Dark background

                # Draw other remote players (Red)
                for p_id, p_info in other_players.items():
                    pygame.draw.rect(screen, (220, 60, 60), (p_info["x"], p_info["y"], 32, 32))

                # Draw local player (Green)
                pygame.draw.rect(screen, (60, 220, 60), (player_data["x"], player_data["y"], 32, 32))

                pygame.display.flip()
                clock.tick(60)

                # CRITICAL FOR PYGBAG: Yield control back to browser event loop
                await asyncio.sleep(0)

    except (OSError, websockets.WebSocketException) as err:
        print(f"Could not connect to WebSocket server: {err}")

    pygame.quit()
    sys.exit()

# Entry point for Pygbag
if __name__ == "__main__":
    asyncio.run(main())